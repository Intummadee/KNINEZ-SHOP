package com.example.customerservice.core.data.customer;


import lombok.Data;

@Data
public class AddressDetail {
    private String address;
    private String province;
    private String zipcode;

}
