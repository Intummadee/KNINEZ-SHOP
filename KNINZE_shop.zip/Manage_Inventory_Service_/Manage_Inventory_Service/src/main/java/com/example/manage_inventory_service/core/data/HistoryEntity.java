//package com.example.manage_inventory_service.core.data;
//
//
//import lombok.AllArgsConstructor;
//import lombok.Data;
//
//import java.util.ArrayList;
//
//@Data
//@AllArgsConstructor
//public class HistoryEntity {
//    private String _id;
//    private String userName;
//    private ArrayList orders;
//}
