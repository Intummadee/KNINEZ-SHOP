package com.example.onlineservice.command.rest;


import lombok.Data;

@Data
public class CategoryQuery {
    private String category;
    private String subcategory;

}
