package com.example.core;

public enum OrderStatus {

    CREATED, APPROVED, REJECTED

}
