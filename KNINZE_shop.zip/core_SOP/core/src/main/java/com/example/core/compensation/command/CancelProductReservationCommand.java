package com.example.core.compensation.command;


import com.example.core.commands.Product_Core;
import lombok.Builder;
import lombok.Data;
import org.axonframework.modelling.command.TargetAggregateIdentifier;

import java.util.ArrayList;

@Data
@Builder
public class CancelProductReservationCommand {
//    กรณี product จำนวนไม่พอ
    @TargetAggregateIdentifier
    private final String onlineId;
    private final String userName;
    private final String orderId;
    private final ArrayList<Product_Core> orders;
    private final String reason;

}
