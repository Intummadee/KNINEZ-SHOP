//package com.example.core.events;
//
//
//import com.example.core.commands.Product;
//import lombok.Builder;
//import lombok.Data;
//
//import java.util.ArrayList;
//
//@Data
//@Builder
//public class OrderCreatedEvent {
//    private String orderId;
//    private String customerId;
//    private ArrayList<Product> orders;
//    private String orderDate;
//    private double totalPrice;
//
//}
