package com.example.demo.data;

import lombok.Data;

@Data
public class AdminRequest {
    private String username;
    private String password;

    // Getters and setters
}